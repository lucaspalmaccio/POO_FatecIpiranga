import java.util.Objects;

public class HistoricoCargo {
    private int id;
    private String cpf;
    private String data;
    private String descricao;
    private Cargo cargo;

    public HistoricoCargo(int id, String cpf, String data, String descricao, Cargo cargo) {
        this.setId(id);
        this.setCpf(cpf);
        this.setData(data);
        this.setDescricao(descricao);
        this.setCargo(cargo);
    }

    public int getId() { return id; }
    public void setId(int id) {
        if (id <= 0) {
            throw new IllegalArgumentException("o id do histórico deve ser um número positivo");
        }
        this.id = id;
    }

    public String getCpf() { return cpf; }
    public void setCpf(String cpf) {
        if (cpf == null || cpf.trim().isEmpty()) {
            throw new IllegalArgumentException("o cpf não pode ser nulo ou vazio");
        }
        this.cpf = cpf;
    }

    public String getData() { return data; }
    public void setData(String data) {
        if (data == null || data.trim().isEmpty()) {
            throw new IllegalArgumentException("a data não pode ser nula ou vazia");
        }
        this.data = data;
    }

    public String getDescricao() { return descricao; }
    public void setDescricao(String descricao) {
        if (descricao == null || descricao.trim().isEmpty()) {
            throw new IllegalArgumentException("a descrição não pode ser nula ou vazia");
        }
        this.descricao = descricao;
    }

    public Cargo getCargo() { return cargo; }
    public void setCargo(Cargo cargo) {
        Objects.requireNonNull(cargo, "o cargo do histórico não pode ser nulo");

        if (Objects.equals(this.cargo, cargo)) {
            return;
        }

        this.cargo = cargo;

        if (!cargo.getHistoricos().contains(this)) {
            cargo.adicionarHistorico(this);
        }
    }
}
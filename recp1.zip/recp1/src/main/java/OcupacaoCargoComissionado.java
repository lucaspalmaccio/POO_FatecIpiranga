import java.util.Objects;
import java.util.UUID;

public class OcupacaoCargoComissionado {
    private UUID id;
    private boolean ativo;
    private boolean bloqueio;
    private VagaComissionadoUnidadeAdministrativa vagaAdministrativa;
    private NivelCargoComissionado nivelCargo;

    public OcupacaoCargoComissionado(UUID id, boolean ativo, boolean bloqueio, VagaComissionadoUnidadeAdministrativa vagaAdmin, NivelCargoComissionado nivelCargo) {
        this.id = Objects.requireNonNull(id);
        this.ativo = ativo;
        this.bloqueio = bloqueio;
        this.setVagaAdministrativa(vagaAdmin);
        this.setNivelCargo(nivelCargo);
    }

    public UUID getId() { return id; }
    public void setId(UUID id) { this.id = Objects.requireNonNull(id); }

    public boolean isAtivo() { return ativo; }
    public void setAtivo(boolean ativo) { this.ativo = ativo; }

    public boolean isBloqueio() { return bloqueio; }
    public void setBloqueio(boolean bloqueio) { this.bloqueio = bloqueio; }

    public VagaComissionadoUnidadeAdministrativa getVagaAdministrativa() { return vagaAdministrativa; }
    public void setVagaAdministrativa(VagaComissionadoUnidadeAdministrativa vagaAdministrativa) {
        this.vagaAdministrativa = Objects.requireNonNull(vagaAdministrativa);
        if (!vagaAdministrativa.getOcupacoes().contains(this)) {
            vagaAdministrativa.adicionarOcupacao(this);
        }
    }

    public NivelCargoComissionado getNivelCargo() { return nivelCargo; }
    public void setNivelCargo(NivelCargoComissionado nivelCargo) {
        this.nivelCargo = Objects.requireNonNull(nivelCargo);
        if(nivelCargo.getOcupacao() != this) {
            nivelCargo.setOcupacao(this);
        }
    }
}
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Cargo {
    private int id;
    private String nome;
    private String codigoESocial;
    private boolean ativo;
    private Lei lei;
    private List<HistoricoCargo> historicos;
    private List<NivelCargoComissionado> niveis;

    public Cargo(int id, String nome, String codigoESocial, boolean ativo, Lei lei) {
        this.setId(id);
        this.setNome(nome);
        this.setCodigoESocial(codigoESocial);
        this.setAtivo(ativo);
        this.historicos = new ArrayList<>();
        this.niveis = new ArrayList<>();
        this.setLei(lei);
    }

    public int getId() { return id; }
    public void setId(int id) {
        if (id <= 0) throw new IllegalArgumentException("id do cargo deve ser positivo");
        this.id = id;
    }

    public String getNome() { return nome; }
    public void setNome(String nome) {
        if (nome == null || nome.trim().isEmpty()) throw new IllegalArgumentException("nome não pode ser nulo ou vazio");
        this.nome = nome;
    }

    public String getCodigoESocial() { return codigoESocial; }
    public void setCodigoESocial(String codigoESocial) {
        if (codigoESocial == null || codigoESocial.trim().isEmpty()) throw new IllegalArgumentException("código esocial não pode ser nulo ou vazio");
        this.codigoESocial = codigoESocial;
    }

    public boolean isAtivo() { return ativo; }
    public void setAtivo(boolean ativo) { this.ativo = ativo; }

    public Lei getLei() { return lei; }
    public void setLei(Lei lei) {
        Objects.requireNonNull(lei, "a lei associada ao cargo não pode ser nula");
        if (Objects.equals(this.lei, lei)) {
            return;
        }

        this.lei = lei;

        if (!lei.getCargos().contains(this)) {
            lei.adicionarCargo(this);
        }
    }

    public List<NivelCargoComissionado> getNiveis() {
        return new ArrayList<>(niveis);
    }

    public void adicionarNivel(NivelCargoComissionado nivel) {
        Objects.requireNonNull(nivel, "nível não pode ser nulo");
        if (!this.niveis.contains(nivel)) {
            this.niveis.add(nivel);
            if (nivel.getCargo() != this) {
                nivel.setCargo(this);
            }
        }
    }

    public List<HistoricoCargo> getHistoricos() {
        return new ArrayList<>(historicos);
    }

    public void adicionarHistorico(HistoricoCargo historico) {
        Objects.requireNonNull(historico, "histórico não pode ser nulo");
        if (!this.historicos.contains(historico)) {
            this.historicos.add(historico);
            if (historico.getCargo() != this) {
                historico.setCargo(this);
            }
        }
    }
}
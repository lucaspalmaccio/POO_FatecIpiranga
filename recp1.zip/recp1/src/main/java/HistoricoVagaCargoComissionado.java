import java.time.LocalDateTime;
import java.util.Objects;

public class HistoricoVagaCargoComissionado {
    private String cpf;
    private LocalDateTime data;
    private String descricao;
    private VagaComissionadoUnidadeGestora vagaGestora;

    public HistoricoVagaCargoComissionado(String cpf, LocalDateTime data, String descricao, VagaComissionadoUnidadeGestora vagaGestora) {
        this.setCpf(cpf);
        this.setData(data);
        this.setDescricao(descricao);
        this.setVagaGestora(vagaGestora);
    }

    public String getCpf() { return cpf; }
    public void setCpf(String cpf) {
        if (cpf == null || cpf.trim().isEmpty()) {
            throw new IllegalArgumentException("cpf não pode ser nulo ou vazio");
        }
        this.cpf = cpf;
    }

    public LocalDateTime getData() { return data; }
    public void setData(LocalDateTime data) {
        this.data = Objects.requireNonNull(data, "data não pode ser nula");
    }

    public String getDescricao() { return descricao; }
    public void setDescricao(String descricao) {
        if (descricao == null || descricao.trim().isEmpty()) {
            throw new IllegalArgumentException("descrição não pode ser nula ou vazia");
        }
        this.descricao = descricao;
    }

    public VagaComissionadoUnidadeGestora getVagaGestora() { return vagaGestora; }
    public void setVagaGestora(VagaComissionadoUnidadeGestora vagaGestora) {
        Objects.requireNonNull(vagaGestora, "vaga gestora não pode ser nula");
        if (Objects.equals(this.vagaGestora, vagaGestora)) {
            return;
        }

        this.vagaGestora = vagaGestora;

        if (!vagaGestora.getHistoricos().contains(this)) {
            vagaGestora.adicionarHistorico(this);
        }
    }
}
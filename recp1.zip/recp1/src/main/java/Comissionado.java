import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Comissionado {
    private Cargo cargo;
    private VagaComissionadoUnidadeGestora vagaGestora;
    private List<NivelCargoComissionado> niveisAgregados;

    public Comissionado(int cargoId, String cargoNome, String cargoCodigoESocial, boolean cargoAtivo, Lei lei, VagaComissionadoUnidadeGestora vagaGestora) {
        this.cargo = new Cargo(cargoId, cargoNome, cargoCodigoESocial, cargoAtivo, lei);
        this.setVagaGestora(vagaGestora);
        this.niveisAgregados = new ArrayList<>();
    }
    public Cargo getCargo() {
        return this.cargo;
    }

    public VagaComissionadoUnidadeGestora getVagaGestora() {
        return vagaGestora;
    }
    public void setVagaGestora(VagaComissionadoUnidadeGestora vagaGestora) {
        this.vagaGestora = Objects.requireNonNull(vagaGestora, "vaga gestora não pode ser nula");
        if (vagaGestora.getComissionado() != this) {
            vagaGestora.setComissionado(this);
        }
    }
    public List<NivelCargoComissionado> getNiveisAgregados() {
        return new ArrayList<>(niveisAgregados);
    }
    public void adicionarNivelAgregado(NivelCargoComissionado nivel) {
        Objects.requireNonNull(nivel, "o nível agregado não pode ser nulo");
        if (!this.niveisAgregados.contains(nivel)) {
            this.niveisAgregados.add(nivel);
        }
    }
}
import java.util.Objects;

public class NivelCargoComissionado {
    private int id;
    private String descricao;
    private String numeracao;
    private String vencimento;
    private Cargo cargo;
    private OcupacaoCargoComissionado ocupacao;

    public NivelCargoComissionado(int id, String descricao, String numeracao, String vencimento, Cargo cargo) {
        this.id = id;
        this.descricao = descricao;
        this.numeracao = numeracao;
        this.vencimento = vencimento;
        this.setCargo(cargo);
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getDescricao() { return descricao; }
    public void setDescricao(String descricao) { this.descricao = descricao; }

    public String getNumeracao() { return numeracao; }
    public void setNumeracao(String numeracao) { this.numeracao = numeracao; }

    public String getVencimento() { return vencimento; }
    public void setVencimento(String vencimento) { this.vencimento = vencimento; }

    public Cargo getCargo() { return cargo; }
    public void setCargo(Cargo cargo) {
        Objects.requireNonNull(cargo, "o cargo do nível não pode ser nulo");
        this.cargo = cargo;
        if (!cargo.getNiveis().contains(this)) {
            cargo.adicionarNivel(this);
        }
    }

    public OcupacaoCargoComissionado getOcupacao() { return ocupacao; }
    public void setOcupacao(OcupacaoCargoComissionado novaOcupacao) {
        if (Objects.equals(this.ocupacao, novaOcupacao)) {
            return;
        }

        OcupacaoCargoComissionado ocupacaoAntiga = this.ocupacao;
        this.ocupacao = novaOcupacao;

        if (ocupacaoAntiga != null) {
            ocupacaoAntiga.setNivelCargo(null);
        }

        if (novaOcupacao != null) {
            novaOcupacao.setNivelCargo(this);
        }
    }
}
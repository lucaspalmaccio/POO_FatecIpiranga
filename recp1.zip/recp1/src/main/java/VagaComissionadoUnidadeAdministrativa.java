import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class VagaComissionadoUnidadeAdministrativa {
    private int totalDeVagas;
    private int unidadeAdministrativa;
    private VagaComissionadoUnidadeGestora vagaGestora;
    private List<OcupacaoCargoComissionado> ocupacoes;

    VagaComissionadoUnidadeAdministrativa(int totalDeVagas, int unidadeAdministrativa, VagaComissionadoUnidadeGestora vagaGestora) {
        this.setTotalDeVagas(totalDeVagas);
        this.unidadeAdministrativa = unidadeAdministrativa;
        this.vagaGestora = Objects.requireNonNull(vagaGestora, "a vaga gestora não pode ser nula");
        this.ocupacoes = new ArrayList<>();
    }

    public int getTotalDeVagas() { return totalDeVagas; }
    public void setTotalDeVagas(int totalDeVagas) {
        if (totalDeVagas < 0) {
            throw new IllegalArgumentException("o total de vagas não pode ser um número negativo");
        }
        this.totalDeVagas = totalDeVagas;
    }

    public int getUnidadeAdministrativa() { return unidadeAdministrativa; }
    public void setUnidadeAdministrativa(int unidadeAdministrativa) { this.unidadeAdministrativa = unidadeAdministrativa; }

    public VagaComissionadoUnidadeGestora getVagaGestora() { return vagaGestora; }

    public List<OcupacaoCargoComissionado> getOcupacoes() {
        return new ArrayList<>(ocupacoes);
    }
    public void adicionarOcupacao(OcupacaoCargoComissionado ocupacao) {
        Objects.requireNonNull(ocupacao);
        if(!this.ocupacoes.contains(ocupacao)) {
            this.ocupacoes.add(ocupacao);
            if(ocupacao.getVagaAdministrativa() != this) {
                ocupacao.setVagaAdministrativa(this);
            }
        }
    }
}
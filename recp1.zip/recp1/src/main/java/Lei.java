import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Lei {
    private int id;
    private LocalDateTime data;
    private String diof;
    private String numeroDaLei;
    private String numeroSei;
    private List<Cargo> cargos;

    public Lei(int id, LocalDateTime data, String diof, String numeroDaLei, String numeroSei) {
        this.setId(id);
        this.setData(data);
        this.setDiof(diof);
        this.setNumeroDaLei(numeroDaLei);
        this.setNumeroSei(numeroSei);
        this.cargos = new ArrayList<>();
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        if (id <= 0) {
            throw new IllegalArgumentException("id da Lei deve ser positivo");
        }
        this.id = id;
    }

    public LocalDateTime getData() {
        return data;
    }

    public void setData(LocalDateTime data) {
        this.data = Objects.requireNonNull(data, "a data não pode ser nula");
    }

    public String getDiof() {
        return diof;
    }

    public void setDiof(String diof) {
        if (diof == null || diof.trim().isEmpty()) {
            throw new IllegalArgumentException("diof não pode ser nulo ou vazio");
        }
        this.diof = diof;
    }

    public String getNumeroDaLei() {
        return numeroDaLei;
    }

    public void setNumeroDaLei(String numeroDaLei) {
        if (numeroDaLei == null || numeroDaLei.trim().isEmpty()) {
            throw new IllegalArgumentException("número da lei não pode ser nulo ou vazio");
        }
        this.numeroDaLei = numeroDaLei;
    }

    public String getNumeroSei() {
        return numeroSei;
    }

    public void setNumeroSei(String numeroSei) {
        if (numeroSei == null || numeroSei.trim().isEmpty()) {
            throw new IllegalArgumentException("número sei não pode ser nulo ou vazio");
        }
        this.numeroSei = numeroSei;
    }

    public List<Cargo> getCargos() {
        return new ArrayList<>(cargos);
    }

    public void adicionarCargo(Cargo cargo) {
        Objects.requireNonNull(cargo, "cargo não pode ser nulo");
        if (!this.cargos.contains(cargo)) {
            this.cargos.add(cargo);
            if (cargo.getLei() != this) {
                cargo.setLei(this);
            }
        }
    }
}
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class VagaComissionadoUnidadeGestora {
    private int id;
    private boolean possuiLimitacao;
    private int totalDeVagas;
    private int unidadeGestoraId;
    private Comissionado comissionado;
    private List<VagaComissionadoUnidadeAdministrativa> vagasAdministrativas;
    private List<HistoricoVagaCargoComissionado> historicos;

    public VagaComissionadoUnidadeGestora(int id, boolean possuiLimitacao, int totalDeVagas, int unidadeGestoraId) {
        this.id = id;
        this.possuiLimitacao = possuiLimitacao;
        this.totalDeVagas = totalDeVagas;
        this.unidadeGestoraId = unidadeGestoraId;
        this.vagasAdministrativas = new ArrayList<>();
        this.historicos = new ArrayList<>();
    }

    public int getId() {
        return id;
    }

    public boolean isPossuiLimitacao() {
        return possuiLimitacao;
    }

    public void setPossuiLimitacao(boolean possuiLimitacao) {
        this.possuiLimitacao = possuiLimitacao;
    }

    public int getTotalDeVagas() {
        return totalDeVagas;
    }

    public void setTotalDeVagas(int totalDeVagas) {
        if (totalDeVagas < 0) {
            throw new IllegalArgumentException("o total de vagas não pode ser negativo");
        }
        this.totalDeVagas = totalDeVagas;
    }

    public int getUnidadeGestoraId() {
        return unidadeGestoraId;
    }

    public void setUnidadeGestoraId(int unidadeGestoraId) {
        this.unidadeGestoraId = unidadeGestoraId;
    }

    public Comissionado getComissionado() {
        return comissionado;
    }

    public void setComissionado(Comissionado comissionado) {
        this.comissionado = Objects.requireNonNull(comissionado, "comissionado não pode ser nulo");
        if (comissionado.getVagaGestora() != this) {
            comissionado.setVagaGestora(this);
        }
    }

    public List<VagaComissionadoUnidadeAdministrativa> getVagasAdministrativas() {
        return new ArrayList<>(vagasAdministrativas);
    }

    public VagaComissionadoUnidadeAdministrativa criarEAdicionarVagaAdministrativa(int totalVagas, int unidadeAdmId) {
        VagaComissionadoUnidadeAdministrativa novaVaga = new VagaComissionadoUnidadeAdministrativa(totalVagas, unidadeAdmId, this);
        this.vagasAdministrativas.add(novaVaga);
        return novaVaga;
    }

    public List<HistoricoVagaCargoComissionado> getHistoricos() {
        return new ArrayList<>(historicos);
    }

    public void adicionarHistorico(HistoricoVagaCargoComissionado historico) {
        Objects.requireNonNull(historico);
        if (!this.historicos.contains(historico)) {
            this.historicos.add(historico);
            if (historico.getVagaGestora() != this) {
                historico.setVagaGestora(this);
            }
        }
    }
}
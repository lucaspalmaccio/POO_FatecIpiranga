class Main {
    public static void main(String[] args) {
        Paciente paciente1 = new Paciente(
                "Norton Glaser",
                "123.456.789-00",
                "(11) 98765-4321",
                "Masculino",
                35
        );

        Medico medico1 = new Medico(
                "Dra. Ana Costa",
                "123456/SP",
                "(11) 91234-5678",
                "Cardiologia",
                "senhaSegura123"
        );

        Recepcionista recepcionista1 = new Recepcionista(
                "Carlos Pereira",
                "111.222.333-44",
                "(11) 2345-6789",
                "senhaNova456"
        );

        Agenda agenda1 = new Agenda("03/09/2025", "10:00", medico1, paciente1);

        Consulta consulta1 = new Consulta(
                "02/09/2025",
                "10:00",
                medico1,
                paciente1,
                "Check-up anual",
                "Paciente sem histórico de doenças cardíacas."
        );

        Receita receita1 = new Receita(
                consulta1,
                "02/09/2025",
                "Tomar 1 comprimido de Vitamina b12 por dia."
        );

        Exame exame1 = new Exame(
                consulta1,
                "02/09/2025",
                "Exame de sangue completo."
        );

        System.out.println("### Exibindo dados dos objetos criados ###\n");

        paciente1.mostrar();
        medico1.mostrar();
        recepcionista1.mostrar();
        agenda1.mostrar();
        consulta1.mostrar();
        receita1.mostrar();
        exame1.mostrar();
    }
}
// Feito por Lucas Palmaccio
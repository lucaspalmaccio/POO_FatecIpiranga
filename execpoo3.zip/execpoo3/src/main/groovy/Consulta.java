public class Consulta {
    private String data;
    private String hora;
    private Medico medico;
    private Paciente paciente;
    private String motivo;
    private String historico;

    public Consulta() {
    }

    public Consulta(String data, String hora, Medico medico, Paciente paciente, String motivo, String historico) {
        this.data = data;
        this.hora = hora;
        this.medico = medico;
        this.paciente = paciente;
        this.motivo = motivo;
        this.historico = historico;
    }

    public String getData() { return data; }
    public void setData(String data) { this.data = data; }
    public String getHora() { return hora; }
    public void setHora(String hora) { this.hora = hora; }
    public Medico getMedico() { return medico; }
    public void setMedico(Medico medico) { this.medico = medico; }
    public Paciente getPaciente() { return paciente; }
    public void setPaciente(Paciente paciente) { this.paciente = paciente; }
    public String getMotivo() { return motivo; }
    public void setMotivo(String motivo) { this.motivo = motivo; }
    public String getHistorico() { return historico; }
    public void setHistorico(String historico) { this.historico = historico; }

    public void marcar() { System.out.println("Consulta marcada."); }
    public void cancelar() { System.out.println("Consulta cancelada."); }
    public void consultar() { System.out.println("Consultando dados da consulta."); }
    public void realizar() { System.out.println("Consulta sendo realizada."); }
    public void atualizar() { System.out.println("Dados da consulta atualizados."); }

    public void mostrar() {
        System.out.println("--- Dados da Consulta ---");
        System.out.println("Data: " + this.data);
        System.out.println("Hora: " + this.hora);
        System.out.println("Médico: " + this.medico.getNome());
        System.out.println("Paciente: " + this.paciente.getNome());
        System.out.println("Motivo: " + this.motivo);
        System.out.println("Histórico: " + this.historico);
        System.out.println();
    }
}
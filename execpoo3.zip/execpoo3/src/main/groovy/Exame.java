public class Exame {
    private Consulta consulta;
    private String data;
    private String descritivo;

    public Exame() {
    }

    public Exame(Consulta consulta, String data, String descritivo) {
        this.consulta = consulta;
        this.data = data;
        this.descritivo = descritivo;
    }

    public Consulta getConsulta() { return consulta; }
    public void setConsulta(Consulta consulta) { this.consulta = consulta; }
    public String getData() { return data; }
    public void setData(String data) { this.data = data; }
    public String getDescritivo() { return descritivo; }
    public void setDescritivo(String descritivo) { this.descritivo = descritivo; }

    public void solicitar() { System.out.println("Exame solicitado."); }
    public void consultar() { System.out.println("Consultando exame."); }

    public void mostrar() {
        System.out.println("--- Dados do Exame ---");
        System.out.println("Data da solicitação: " + this.data);
        System.out.println("Associado à consulta de: " + this.consulta.getData() + " com o paciente " + this.consulta.getPaciente().getNome());
        System.out.println("Descritivo: " + this.descritivo);
        System.out.println();
    }
}
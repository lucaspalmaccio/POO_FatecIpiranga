class Exame {
    Consulta consulta;
    String data;
    String descritivo;

    void solicitar() {
        System.out.println("Exame solicitado.");
    }

    void consultar() {
        System.out.println("Consultando exame.");
    }

    void mostrar() {
        System.out.println("--- Dados do Exame ---");
        System.out.println("Data da solicitação: " + this.data);
        System.out.println("Associado à consulta de: " + this.consulta.data + " com o paciente " + this.consulta.paciente.nome);
        System.out.println("Descritivo: " + this.descritivo);
        System.out.println();
    }
}

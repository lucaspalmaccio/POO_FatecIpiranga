class Agenda {
    String data;
    String hora;
    Medico medico;
    Paciente paciente;

    void consultar() {
        System.out.println("Consultando a agenda.");
    }

    void mostrar() {
        System.out.println("--- Dados da Agenda ---");
        System.out.println("Data: " + this.data);
        System.out.println("Hora: " + this.hora);
        System.out.println("Médico: " + this.medico.nome);
        System.out.println("Paciente: " + this.paciente.nome);
        System.out.println();
    }
}
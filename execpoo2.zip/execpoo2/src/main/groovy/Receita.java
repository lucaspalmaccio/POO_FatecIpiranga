class Receita {
    Consulta consulta;
    String data;
    String descritivo;

    void prescrever() {
        System.out.println("Receita prescrita.");
    }

    void consultar() {
        System.out.println("Consultando receita.");
    }

    void mostrar() {
        System.out.println("--- Dados da Receita ---");
        System.out.println("Data: " + this.data);
        System.out.println("Associada à consulta de: " + this.consulta.data + " com o paciente " + this.consulta.paciente.nome);
        System.out.println("Descritivo: " + this.descritivo);
        System.out.println();
    }
}
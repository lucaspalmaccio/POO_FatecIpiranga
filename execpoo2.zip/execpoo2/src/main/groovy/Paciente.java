class Paciente {
    String nome;
    String cpf;
    String telefone;
    String genero;
    int idade;

    void cadastrar() {
        System.out.println("Paciente cadastrado no sistema.");
    }

    void consultar() {
        System.out.println("Consultando dados do paciente.");
    }

    void mostrar() {
        System.out.println("--- Dados do Paciente ---");
        System.out.println("Nome: " + this.nome);
        System.out.println("CPF: " + this.cpf);
        System.out.println("Telefone: " + this.telefone);
        System.out.println("Gênero: " + this.genero);
        System.out.println("Idade: " + this.idade);
        System.out.println();
    }
}
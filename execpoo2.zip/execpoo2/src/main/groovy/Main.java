public class Main {
    public static void main(String[] args) {
        Paciente paciente1 = new Paciente();
        paciente1.nome = "Norton Glaser";
        paciente1.cpf = "123.456.789-00";
        paciente1.telefone = "(11) 98999-9999";
        paciente1.genero = "Masculino";
        paciente1.idade = 30;

        Medico medico1 = new Medico();
        medico1.nome = "Dra. Ana Costa";
        medico1.crm = "123456/SP";
        medico1.telefone = "(11) 91234-5678";
        medico1.especialidade = "Cardiologia";
        medico1.senha = "senhaSegura123";

        Recepcionista recepcionista1 = new Recepcionista();
        recepcionista1.nome = "Carlos Pereira";
        recepcionista1.cpf = "111.222.333-44";
        recepcionista1.telefone = "(11) 2345-6789";
        recepcionista1.senha = "outraSenha456";

        Agenda agenda1 = new Agenda();
        agenda1.data = "28/08/2025";
        agenda1.hora = "10:00";
        agenda1.medico = medico1;
        agenda1.paciente = paciente1;

        Consulta consulta1 = new Consulta();
        consulta1.data = "28/08/2025";
        consulta1.hora = "10:00";
        consulta1.medico = medico1;
        consulta1.paciente = paciente1;
        consulta1.motivo = "Check-up anual";
        consulta1.historico = "Paciente sem histórico de doenças cardíacas.";

        Receita receita1 = new Receita();
        receita1.consulta = consulta1;
        receita1.data = "28/08/2025";
        receita1.descritivo = "Tomar 1 comprimido de Vitamina b12 por dia.";

        Exame exame1 = new Exame();
        exame1.consulta = consulta1;
        exame1.data = "28/08/2025";
        exame1.descritivo = "Exame de sangue completo (hemograma).";

        System.out.println("Exibindo Dados dos Objetos Criados\n");

        paciente1.mostrar();
        medico1.mostrar();
        recepcionista1.mostrar();
        agenda1.mostrar();
        consulta1.mostrar();
        receita1.mostrar();
        exame1.mostrar();
    }
}
// Feito por Lucas Palmaccio
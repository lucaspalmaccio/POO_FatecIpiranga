class Recepcionista {
    String nome;
    String cpf;
    String telefone;
    String senha;

    void acessar() {
        System.out.println("Recepcionista acessou o sistema.");
    }

    void mostrar() {
        System.out.println("--- Dados da Recepcionista ---");
        System.out.println("Nome: " + this.nome);
        System.out.println("CPF: " + this.cpf);
        System.out.println("Telefone: " + this.telefone);
        System.out.println();
    }
}

class Consulta {
    String data;
    String hora;
    Medico medico;
    Paciente paciente;
    String motivo;
    String historico;

    void marcar() {
        System.out.println("Consulta marcada.");
    }

    void cancelar() {
        System.out.println("Consulta cancelada.");
    }

    void consultar() {
        System.out.println("Consultando dados da consulta.");
    }

    void realizar() {
        System.out.println("Consulta sendo realizada.");
    }

    void atualizar() {
        System.out.println("Dados da consulta atualizados.");
    }

    void mostrar() {
        System.out.println("--- Dados da Consulta ---");
        System.out.println("Data: " + this.data);
        System.out.println("Hora: " + this.hora);
        System.out.println("Médico: " + this.medico.nome);
        System.out.println("Paciente: " + this.paciente.nome);
        System.out.println("Motivo: " + this.motivo);
        System.out.println("Histórico: " + this.historico);
        System.out.println();
    }
}

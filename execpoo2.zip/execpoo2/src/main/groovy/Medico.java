class Medico {
    String nome;
    String crm;
    String telefone;
    String especialidade;
    String senha;

    void acessar() {
        System.out.println("Médico acessou o sistema.");
    }

    void mostrar() {
        System.out.println("--- Dados do Médico ---");
        System.out.println("Nome: " + this.nome);
        System.out.println("CRM: " + this.crm);
        System.out.println("Telefone: " + this.telefone);
        System.out.println("Especialidade: " + this.especialidade);
        System.out.println();
    }
}